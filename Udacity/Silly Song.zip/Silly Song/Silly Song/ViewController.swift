//
//  ViewController.swift
//  Silly Song
//
//  Created by Douglas MacbookPro on 12/14/16.
//  Copyright © 2016 Douglas MacbookPro. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var lyricsView: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        nameField.delegate = self
    }

    @IBAction func reset(_ sender: Any) {
        nameField.text = ""
        lyricsView.text = ""
    }

    @IBAction func displayLyrics(_ sender: Any) {
        let lyrics = nameField.text
        if (lyrics?.isEmpty)!{
            lyricsView.text = "Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nam liber te conscient to factor tum poen legum odioque civiuda."
        }
        else{
            lyricsView.text = lyricsForName(lyricsTemplate: bananaFanaTemplate, fullName: lyrics!)
        }
    }
}


// MARK: - UITextFieldDelegate
extension ViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return false
    }
}

func shortNameFromName(_ name: String) -> String{
    var shortname = name.lowercased()
    
    let vowels: [Character] = ["a","e","i","o","u"]
    
    for character in shortname.characters{
        if !vowels.contains(character){
            shortname.remove(at: shortname.startIndex)
        }
        else{
            break
        }
    }
    return shortname
}


func lyricsForName(lyricsTemplate: String, fullName:String) -> String {
    let shortname = shortNameFromName(fullName)
    let sillySong = lyricsTemplate
        .replacingOccurrences(of: "<FULL_NAME>", with: fullName)
        .replacingOccurrences(of: "<SHORT_NAME>", with: shortname)
    
    return sillySong
}

let bananaFanaTemplate = [
    "<FULL_NAME>, <FULL_NAME>, Bo B<SHORT_NAME>",
    "Banana Fana Fo F<SHORT_NAME>",
    "Me My Mo M<SHORT_NAME>",
    "<FULL_NAME>"].joined(separator: "\n")
